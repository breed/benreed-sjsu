# Project Description

This is the my (Ben Reed) home page for SJSU.
The domain of the page is ben.homeofcode.com

# Tools

- ben.homeofcode.com uses github pages
- homeofcode.com is in EasyDNS

# Content

- the original content is from https://www.sjsu.edu/people/ben.reed/
- preserve the original content exactly as it is
